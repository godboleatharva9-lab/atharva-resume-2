export const PROFILE = {
  name: "Atharva Godbole",
  role: "Corporate Finance Aspirant",
  email: "godboleatharva9@gmail.com",
  linkedin: "https://www.linkedin.com/in/atharva-godbole-573024419",
  linkedinLabel: "linkedin.com/in/atharva-godbole-573024419",
  location: "Pune, India",
};

export const NAV_LINKS = [
  { id: "about", label: "About" },
  { id: "education", label: "Education" },
  { id: "experience", label: "Experience" },
  { id: "skills", label: "Skills" },
  { id: "activities", label: "Activities" },
  { id: "contact", label: "Contact" },
];

export const HERO_STATS = [
  { value: "8.81", label: "Graduation CGPA" },
  { value: "3 mo", label: "Taxation Internship" },
  { value: "3+ yrs", label: "Theatre" },
];

export const MARQUEE_ITEMS = [
  "Financial Modelling",
  "ITR · TDS · GST",
  "AI Prompt Engineering",
  "MS Excel",
  "CGPA 8.81 (A+)",
  "IMDR Pune",
];

export const EDUCATION = [
  {
    degree: "PGDM — Finance",
    school: "IMDR (DES Institute of Management Development and Research), Pune",
    period: "2026–28",
    detail: "In progress — building depth in Corporate Finance.",
  },
  {
    degree: "Graduation",
    school: "Indsearch Institute of Cost and Management",
    period: "2023–26",
    detail: "CGPA 8.81 (A+)",
  },
  {
    degree: "HSC",
    school: "MIT Junior College",
    period: "2023",
    detail: null,
  },
  {
    degree: "SSC",
    school: "Maharashtra Mandal English Medium School",
    period: null,
    detail: null,
  },
];

export const EXPERIENCE = {
  role: "Finance & Taxation Intern",
  org: "CA Office",
  period: "3 months",
  points: [
    "Prepared and filed Income Tax Returns (ITR) for individual clients.",
    "Handled TDS computation and filing.",
    "Assisted with GST filing and compliance work.",
  ],
};

export const SKILL_BARS = [
  { label: "Taxation — ITR · TDS · GST", pct: 85, tag: null },
  { label: "MS Excel", pct: 80, tag: null },
  { label: "Financial Modelling", pct: 45, tag: "currently learning" },
];

export const AI_SKILL = { label: "AI Tools & Prompt Engineering", pct: 90 };

export const LANGUAGES = [
  { name: "English", level: "Professional" },
  { name: "Hindi", level: "Fluent" },
  { name: "Marathi", level: "Native" },
];
