import { motion } from "framer-motion";
import { Sparkles, TrendingUp, FileSpreadsheet, Calculator } from "lucide-react";
import SectionHeading from "./SectionHeading";
import { SKILL_BARS, AI_SKILL } from "../data/resume";

const EASE = [0.16, 1, 0.3, 1];

const Bar = ({ label, pct, tag, delay }) => (
  <div>
    <div className="flex items-center justify-between gap-3 mb-2">
      <p className="flex items-center gap-2 text-sm font-semibold text-slate-800 dark:text-slate-200">
        {label}
        {tag && (
          <span className="rounded-full border border-accent/30 bg-accent/10 px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.15em] text-accent">
            {tag}
          </span>
        )}
      </p>
      <p className="font-mono text-xs text-slate-500 dark:text-slate-400">{pct}%</p>
    </div>
    <div className="h-2 w-full rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
      <motion.div
        initial={{ width: 0 }}
        whileInView={{ width: `${pct}%` }}
        viewport={{ once: true, amount: 0.4 }}
        transition={{ duration: 1.2, delay, ease: EASE }}
        className="h-full rounded-full bg-accent shadow-[0_0_12px_rgba(0,163,255,0.55)]"
      />
    </div>
  </div>
);

export default function Skills() {
  return (
    <section
      id="skills"
      data-testid="skills-section"
      className="py-20 sm:py-28 bg-[#EDF2F7] dark:bg-[#0B1120]"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading overline="Skills" title="The toolkit." />
        <div className="grid gap-6 lg:grid-cols-12">
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.7, ease: EASE }}
            className="lg:col-span-5"
          >
            <div
              data-testid="ai-spotlight-card"
              className="ai-card relative h-full rounded-3xl bg-white dark:bg-[#0F172A] p-8 sm:p-10 overflow-hidden"
            >
              <div className="absolute -right-10 -top-10 h-44 w-44 rounded-full bg-accent/15 blur-3xl" />
              <div className="relative z-[2]">
                <span className="inline-flex items-center gap-2 rounded-full border border-accent/40 bg-accent/10 px-3.5 py-1.5 font-mono text-[11px] uppercase tracking-[0.2em] text-accent">
                  <Sparkles className="h-3.5 w-3.5" />
                  Signature Skill
                </span>
                <h3 className="mt-5 font-serif text-2xl sm:text-3xl font-semibold text-slate-900 dark:text-white">
                  AI Tools & Prompt Engineering
                </h3>
                <p className="mt-4 text-sm sm:text-base leading-relaxed text-slate-600 dark:text-slate-400">
                  I use AI the way analysts use Excel — daily, deliberately,
                  and with judgment. Prompt engineering sharpens research,
                  drafting and modelling workflows end to end.
                </p>
                <div className="mt-8">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                      {AI_SKILL.label}
                    </p>
                    <p className="font-mono text-xs text-accent">{AI_SKILL.pct}%</p>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${AI_SKILL.pct}%` }}
                      viewport={{ once: true, amount: 0.4 }}
                      transition={{ duration: 1.2, ease: EASE }}
                      className="h-full rounded-full bg-accent shadow-[0_0_12px_rgba(0,163,255,0.55)]"
                    />
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.7, delay: 0.12, ease: EASE }}
            className="lg:col-span-7"
          >
            <div className="h-full rounded-3xl border border-slate-900/10 dark:border-white/10 bg-white dark:bg-[#0F172A] p-8 sm:p-10 flex flex-col justify-center gap-8">
              {SKILL_BARS.map((s, i) => (
                <Bar key={s.label} {...s} delay={i * 0.15} />
              ))}
              <div className="flex flex-wrap gap-2.5 pt-2">
                {[
                  { icon: Calculator, label: "Corporate Finance" },
                  { icon: FileSpreadsheet, label: "Advanced Excel" },
                  { icon: TrendingUp, label: "Compliance" },
                ].map((chip) => (
                  <span
                    key={chip.label}
                    className="inline-flex items-center gap-2 rounded-full border border-slate-900/10 dark:border-white/10 bg-slate-50 dark:bg-white/5 px-4 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 transition-all duration-200 hover:border-accent/40 hover:text-accent"
                  >
                    <chip.icon className="h-3.5 w-3.5" />
                    {chip.label}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
