import { motion } from "framer-motion";
import { Check, Briefcase } from "lucide-react";
import SectionHeading from "./SectionHeading";
import { EXPERIENCE } from "../data/resume";

const EASE = [0.16, 1, 0.3, 1];

export default function Experience() {
  return (
    <section id="experience" data-testid="experience-section" className="py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading overline="Experience" title="Where the tax returns got real." />
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.15 }}
          transition={{ duration: 0.7, ease: EASE }}
          className="relative overflow-hidden rounded-3xl border border-slate-900/10 dark:border-white/10 bg-white dark:bg-[#0F172A] p-7 sm:p-12 transition-all duration-200 hover:border-accent/40 hover:shadow-[0_0_40px_rgba(0,163,255,0.12)]"
        >
          <div className="absolute -right-8 -top-8 h-40 w-40 rounded-full bg-accent/10 blur-2xl" />
          <div className="flex flex-wrap items-start justify-between gap-6">
            <div>
              <p className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.25em] text-accent">
                <Briefcase className="h-3.5 w-3.5" />
                Featured role
              </p>
              <h3 className="mt-3 font-serif text-2xl sm:text-3xl font-semibold text-slate-900 dark:text-white">
                {EXPERIENCE.role}
              </h3>
              <p className="mt-1.5 text-sm text-slate-600 dark:text-slate-400">
                {EXPERIENCE.org}
              </p>
            </div>
            <div className="rounded-2xl border border-accent/30 bg-accent/10 px-5 py-3 text-center">
              <p className="font-mono text-2xl font-semibold text-accent">03</p>
              <p className="text-[10px] uppercase tracking-[0.2em] text-slate-600 dark:text-slate-400">
                months
              </p>
            </div>
          </div>

          <div className="mt-8 border-t border-slate-900/10 dark:border-white/10 pt-8">
            <ul className="space-y-4 max-w-2xl">
              {EXPERIENCE.points.map((p, i) => (
                <motion.li
                  key={p}
                  initial={{ opacity: 0, x: -16 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, amount: 0.15 }}
                  transition={{ duration: 0.5, delay: 0.15 + i * 0.1, ease: EASE }}
                  className="flex items-start gap-3 text-sm sm:text-base text-slate-700 dark:text-slate-300"
                >
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-accent/15">
                    <Check className="h-3 w-3 text-accent" />
                  </span>
                  {p}
                </motion.li>
              ))}
            </ul>
            <div className="mt-8 flex flex-wrap gap-2.5">
              {["ITR Filing", "TDS", "GST"].map((chip) => (
                <span
                  key={chip}
                  className="rounded-full border border-slate-900/10 dark:border-white/10 bg-slate-50 dark:bg-white/5 px-4 py-1.5 font-mono text-xs text-slate-700 dark:text-slate-300"
                >
                  {chip}
                </span>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
