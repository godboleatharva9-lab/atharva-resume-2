import { useState } from "react";
import { motion } from "framer-motion";
import { Mail, Linkedin, MapPin, Send, LoaderCircle } from "lucide-react";
import { toast } from "sonner";
import SectionHeading from "./SectionHeading";
import { PROFILE } from "../data/resume";

const EASE = [0.16, 1, 0.3, 1];
const API = `${process.env.REACT_APP_BACKEND_URL || ""}/api/contact`;

const inputCls =
  "w-full rounded-xl border border-slate-900/10 dark:border-white/10 bg-slate-50 dark:bg-white/5 px-4 py-3 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 outline-none transition-all duration-200 focus:border-accent focus:ring-2 focus:ring-accent/25";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sending, setSending] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setSending(true);
    try {
      const r = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!r.ok) throw new Error("send failed");
      toast.success("Message sent — I'll get back to you soon.");
      setForm({ name: "", email: "", message: "" });
    } catch {
      toast.error("Couldn't send the message. Please email me directly.");
    } finally {
      setSending(false);
    }
  };

  return (
    <section
      id="contact"
      data-testid="contact-section"
      className="py-20 sm:py-28 bg-[#EDF2F7] dark:bg-[#0B1120]"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading overline="Contact" title="Let's talk numbers." />
        <div className="grid gap-10 lg:grid-cols-12 lg:gap-14">
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.7, ease: EASE }}
            className="lg:col-span-5"
          >
            <p className="text-base sm:text-lg leading-relaxed text-slate-600 dark:text-slate-400 max-w-md">
              Internships, roles, or a quick finance chat — my inbox is open
              and my CV is one click away.
            </p>
            <div className="mt-8 space-y-4">
              <a
                data-testid="contact-email-link"
                href={`mailto:${PROFILE.email}`}
                className="flex items-center gap-4 rounded-2xl border border-slate-900/10 dark:border-white/10 bg-white dark:bg-[#0F172A] p-5 transition-all duration-200 hover:border-accent/40 hover:shadow-[0_0_24px_rgba(0,163,255,0.12)]"
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/10">
                  <Mail className="h-5 w-5 text-accent" />
                </span>
                <span>
                  <span className="block text-[11px] font-mono uppercase tracking-[0.2em] text-slate-500 dark:text-slate-400">
                    Email
                  </span>
                  <span className="block text-sm font-semibold text-slate-900 dark:text-white">
                    {PROFILE.email}
                  </span>
                </span>
              </a>
              <a
                data-testid="contact-linkedin-link"
                href={PROFILE.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 rounded-2xl border border-slate-900/10 dark:border-white/10 bg-white dark:bg-[#0F172A] p-5 transition-all duration-200 hover:border-accent/40 hover:shadow-[0_0_24px_rgba(0,163,255,0.12)]"
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/10">
                  <Linkedin className="h-5 w-5 text-accent" />
                </span>
                <span>
                  <span className="block text-[11px] font-mono uppercase tracking-[0.2em] text-slate-500 dark:text-slate-400">
                    LinkedIn
                  </span>
                  <span className="block text-sm font-semibold text-slate-900 dark:text-white">
                    {PROFILE.linkedinLabel}
                  </span>
                </span>
              </a>
              <div className="flex items-center gap-4 rounded-2xl border border-slate-900/10 dark:border-white/10 bg-white dark:bg-[#0F172A] p-5">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/10">
                  <MapPin className="h-5 w-5 text-accent" />
                </span>
                <span>
                  <span className="block text-[11px] font-mono uppercase tracking-[0.2em] text-slate-500 dark:text-slate-400">
                    Location
                  </span>
                  <span className="block text-sm font-semibold text-slate-900 dark:text-white">
                    {PROFILE.location}
                  </span>
                </span>
              </div>
            </div>
          </motion.div>

          <motion.form
            onSubmit={submit}
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.7, delay: 0.12, ease: EASE }}
            className="lg:col-span-7 rounded-3xl border border-slate-900/10 dark:border-white/10 bg-white dark:bg-[#0F172A] p-7 sm:p-10"
          >
            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="contact-name"
                  className="mb-2 block text-xs font-mono uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400"
                >
                  Name
                </label>
                <input
                  id="contact-name"
                  data-testid="contact-name-input"
                  required
                  maxLength={120}
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Your name"
                  className={inputCls}
                />
              </div>
              <div>
                <label
                  htmlFor="contact-email"
                  className="mb-2 block text-xs font-mono uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400"
                >
                  Email
                </label>
                <input
                  id="contact-email"
                  data-testid="contact-email-input"
                  type="email"
                  required
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="you@example.com"
                  className={inputCls}
                />
              </div>
            </div>
            <div className="mt-5">
              <label
                htmlFor="contact-message"
                className="mb-2 block text-xs font-mono uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400"
              >
                Message
              </label>
              <textarea
                id="contact-message"
                data-testid="contact-message-input"
                required
                maxLength={4000}
                rows={6}
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                placeholder="What would you like to discuss?"
                className={`${inputCls} resize-none`}
              />
            </div>
            <button
              type="submit"
              data-testid="contact-submit-button"
              disabled={sending}
              className="mt-7 inline-flex items-center gap-2 rounded-full bg-accent px-7 py-3 text-sm font-semibold text-[#04121F] hover:scale-[1.03] active:scale-[0.98] transition-transform duration-200 shadow-[0_0_28px_rgba(0,163,255,0.3)] disabled:opacity-60 disabled:hover:scale-100"
            >
              {sending ? (
                <LoaderCircle className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
              {sending ? "Sending…" : "Send message"}
            </button>
          </motion.form>
        </div>
      </div>
    </section>
  );
}
