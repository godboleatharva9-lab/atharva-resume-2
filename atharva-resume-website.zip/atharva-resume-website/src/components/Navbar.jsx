import { useState } from "react";
import { Menu, X, Linkedin, Moon, Sun } from "lucide-react";
import { useTheme } from "../context/ThemeContext";
import { PROFILE, NAV_LINKS } from "../data/resume";
import { scrollToId } from "../lib/scroll";

export const LogoMark = ({ className = "h-8 w-8" }) => (
  <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
    <rect width="64" height="64" rx="14" fill="#0B132B" />
    <path
      d="M18 46 L32 18 L46 46"
      stroke="#00A3FF"
      strokeWidth="5"
      fill="none"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path d="M24.5 36.5 H39.5" stroke="#F8FAFC" strokeWidth="5" strokeLinecap="round" />
  </svg>
);

export default function Navbar() {
  const { theme, toggleTheme } = useTheme();
  const [open, setOpen] = useState(false);

  const go = (id) => {
    setOpen(false);
    scrollToId(id);
  };

  return (
    <header className="fixed top-0 inset-x-0 z-50 px-3 sm:px-6">
      <nav
        data-testid="navbar"
        className="mx-auto mt-3 max-w-6xl rounded-2xl border border-slate-900/10 dark:border-white/10 bg-white/85 dark:bg-[#0B1120]/85 backdrop-blur-xl backdrop-saturate-150 shadow-[0_8px_30px_rgba(2,8,23,0.08)]"
      >
        <div className="flex h-14 items-center justify-between px-4 sm:px-5">
          <button
            data-testid="navbar-logo-link"
            onClick={() => go("hero")}
            className="group flex items-center gap-2.5"
          >
            <LogoMark className="h-8 w-8 transition-transform duration-200 group-hover:scale-105 group-active:scale-95" />
            <span className="font-serif text-lg font-semibold tracking-tight text-slate-900 dark:text-white">
              Atharva Godbole
            </span>
          </button>

          <div className="hidden md:flex items-center gap-0.5">
            {NAV_LINKS.map((l) => (
              <button
                key={l.id}
                data-testid={`nav-link-${l.id}`}
                onClick={() => go(l.id)}
                className="px-3 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-slate-900/5 dark:hover:bg-white/5 transition-colors duration-200"
              >
                {l.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1">
            <a
              data-testid="navbar-linkedin-link"
              href={PROFILE.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn profile"
              className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:text-accent hover:bg-slate-900/5 dark:hover:bg-white/5 transition-colors duration-200"
            >
              <Linkedin className="h-[18px] w-[18px]" />
            </a>
            <button
              data-testid="theme-toggle-button"
              onClick={toggleTheme}
              aria-label="Toggle light or dark mode"
              className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:text-accent hover:bg-slate-900/5 dark:hover:bg-white/5 transition-colors duration-200"
            >
              {theme === "dark" ? (
                <Sun className="h-[18px] w-[18px]" />
              ) : (
                <Moon className="h-[18px] w-[18px]" />
              )}
            </button>
            <button
              data-testid="nav-mobile-toggle-button"
              onClick={() => setOpen((o) => !o)}
              aria-label="Open menu"
              className="md:hidden p-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-900/5 dark:hover:bg-white/5 transition-colors duration-200"
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {open && (
          <div
            data-testid="nav-mobile-menu"
            className="md:hidden border-t border-slate-900/10 dark:border-white/10 px-3 py-3 flex flex-col gap-1"
          >
            {NAV_LINKS.map((l) => (
              <button
                key={l.id}
                data-testid={`nav-mobile-link-${l.id}`}
                onClick={() => go(l.id)}
                className="text-left px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-900/5 dark:hover:bg-white/5 transition-colors duration-200"
              >
                {l.label}
              </button>
            ))}
          </div>
        )}
      </nav>
    </header>
  );
}
