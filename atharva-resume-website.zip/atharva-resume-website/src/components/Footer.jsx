import { Linkedin, Mail, Download } from "lucide-react";
import { LogoMark } from "./Navbar";
import { PROFILE } from "../data/resume";

export default function Footer() {
  return (
    <footer className="border-t border-slate-900/10 dark:border-white/10 bg-[#0B132B] text-white">
      <div className="mx-auto max-w-6xl px-5 sm:px-8 py-12">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-8">
          <div className="flex items-center gap-3">
            <LogoMark className="h-10 w-10" />
            <div>
              <p className="font-serif text-lg font-semibold">Atharva Godbole</p>
              <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-[#7CD4FF]">
                Corporate Finance Aspirant
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a
              data-testid="footer-download-cv-link"
              href={`${process.env.REACT_APP_BACKEND_URL || ""}/api/resume`}
              download
              className="inline-flex items-center gap-2 rounded-full border border-white/25 px-4 py-2 text-xs font-semibold hover:border-accent/70 hover:text-[#7CD4FF] transition-colors duration-200"
            >
              <Download className="h-3.5 w-3.5" />
              CV
            </a>
            <a
              data-testid="footer-linkedin-link"
              href={PROFILE.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn profile"
              className="rounded-full border border-white/25 p-2.5 hover:border-accent/70 hover:text-[#7CD4FF] transition-colors duration-200"
            >
              <Linkedin className="h-4 w-4" />
            </a>
            <a
              data-testid="footer-email-link"
              href={`mailto:${PROFILE.email}`}
              aria-label="Email Atharva"
              className="rounded-full border border-white/25 p-2.5 hover:border-accent/70 hover:text-[#7CD4FF] transition-colors duration-200"
            >
              <Mail className="h-4 w-4" />
            </a>
          </div>
        </div>
        <p className="mt-10 text-xs text-slate-500">
          © {new Date().getFullYear()} Atharva Godbole. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
