import { MARQUEE_ITEMS } from "../data/resume";

const Row = ({ hidden }) => (
  <div aria-hidden={hidden || undefined} className="flex shrink-0 items-center">
    {MARQUEE_ITEMS.map((t, i) => (
      <span key={`${t}-${i}`} className="flex items-center">
        <span className="whitespace-nowrap px-6 sm:px-10 font-mono text-xs sm:text-sm uppercase tracking-[0.25em] text-slate-500 dark:text-slate-400">
          {t}
        </span>
        <span className="h-1.5 w-1.5 rotate-45 bg-accent shrink-0" />
      </span>
    ))}
  </div>
);

export default function Marquee() {
  return (
    <div
      data-testid="marquee"
      className="relative overflow-hidden border-y border-slate-900/10 dark:border-white/10 bg-[#EDF2F7] dark:bg-[#0B1120] py-4"
    >
      <div className="marquee-track flex w-max">
        <Row />
        <Row hidden />
      </div>
    </div>
  );
}
