import { motion } from "framer-motion";
import { Theater, Languages as LanguagesIcon, GraduationCap } from "lucide-react";
import SectionHeading from "./SectionHeading";
import { LANGUAGES } from "../data/resume";

const EASE = [0.16, 1, 0.3, 1];

const cards = [
  {
    icon: Theater,
    stat: "3+ yrs",
    statLabel: "Theatre",
    body: "Stage presence, timing and holding a room — rehearsed on stage, applied everywhere.",
    extra: null,
  },
  {
    icon: LanguagesIcon,
    stat: "03",
    statLabel: "Languages",
    body: null,
    extra: LANGUAGES,
  },
  {
    icon: GraduationCap,
    stat: "8.81 (A+)",
    statLabel: "Graduation CGPA",
    body: "Indsearch Institute of Cost and Management · 2023–26.",
    extra: null,
  },
];

export default function Activities() {
  return (
    <section id="activities" data-testid="activities-section" className="py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading
          overline="Achievements & Activities"
          title="Beyond the balance sheet."
        />
        <div className="grid gap-6 md:grid-cols-3">
          {cards.map((c, i) => (
            <motion.div
              key={c.statLabel}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.15 }}
              transition={{ duration: 0.6, delay: i * 0.1, ease: EASE }}
              className="h-full rounded-3xl border border-slate-900/10 dark:border-white/10 bg-white dark:bg-[#0F172A] p-8 transition-all duration-200 hover:border-accent/40 hover:shadow-[0_0_28px_rgba(0,163,255,0.12)]"
            >
              <c.icon className="h-5 w-5 text-accent" />
              <p className="mt-6 font-mono text-3xl font-semibold text-slate-900 dark:text-white">
                {c.stat}
              </p>
              <p className="mt-1 text-[11px] font-mono uppercase tracking-[0.2em] text-accent">
                {c.statLabel}
              </p>
              {c.body && (
                <p className="mt-4 text-sm leading-relaxed text-slate-600 dark:text-slate-400">
                  {c.body}
                </p>
              )}
              {c.extra && (
                <ul className="mt-4 space-y-2.5">
                  {c.extra.map((l) => (
                    <li
                      key={l.name}
                      className="flex items-center justify-between border-b border-slate-900/5 dark:border-white/5 pb-2 text-sm text-slate-700 dark:text-slate-300 last:border-0 last:pb-0"
                    >
                      <span className="font-medium">{l.name}</span>
                      <span className="font-mono text-xs text-slate-500 dark:text-slate-400">
                        {l.level}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
