import { motion } from "framer-motion";
import SectionHeading from "./SectionHeading";
import { EDUCATION } from "../data/resume";

const EASE = [0.16, 1, 0.3, 1];

export default function Education() {
  return (
    <section
      id="education"
      data-testid="education-section"
      className="py-20 sm:py-28 bg-[#EDF2F7] dark:bg-[#0B1120]"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading overline="Education" title="The ledger so far." />
        <div className="relative border-l border-slate-900/10 dark:border-white/10 pl-8 sm:pl-10 space-y-10 max-w-3xl">
          {EDUCATION.map((e, i) => (
            <motion.div
              key={e.school}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.15 }}
              transition={{ duration: 0.6, delay: i * 0.08, ease: EASE }}
              className="relative"
            >
              <span className="absolute -left-[37px] sm:-left-[45px] top-1.5 h-3 w-3 rounded-full border-2 border-accent bg-white dark:bg-[#050811] shadow-[0_0_12px_rgba(0,163,255,0.6)]" />
              <div className="flex flex-wrap items-center gap-3">
                <h3 className="font-serif text-xl sm:text-2xl font-semibold text-slate-900 dark:text-white">
                  {e.degree}
                </h3>
                {e.period && (
                  <span className="rounded-full border border-accent/30 bg-accent/10 px-2.5 py-0.5 font-mono text-[11px] uppercase tracking-[0.18em] text-accent">
                    {e.period}
                  </span>
                )}
              </div>
              <p className="mt-1.5 text-sm text-slate-600 dark:text-slate-400">
                {e.school}
              </p>
              {e.detail && (
                <p className="mt-1 text-sm font-semibold text-slate-900 dark:text-slate-200">
                  {e.detail}
                </p>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
