import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Download, ArrowDown, Linkedin } from "lucide-react";
import { HERO_STATS, PROFILE } from "../data/resume";
import { scrollToId } from "../lib/scroll";

const EASE = [0.16, 1, 0.3, 1];

const RevealLine = ({ children, delay }) => (
  <span className="block overflow-hidden pb-1">
    <motion.span
      className="block will-change-transform"
      initial={{ y: "112%" }}
      animate={{ y: 0 }}
      transition={{ duration: 1, delay, ease: EASE }}
    >
      {children}
    </motion.span>
  </span>
);

export default function Hero() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", "22%"]);
  const fade = useTransform(scrollYProgress, [0, 0.75], [1, 0]);

  return (
    <section
      id="hero"
      ref={ref}
      data-testid="hero-section"
      className="relative min-h-screen flex flex-col justify-end overflow-hidden bg-[#0B132B] text-white"
    >
      <motion.div style={{ y: bgY }} className="absolute inset-x-0 -top-[12%] -bottom-[16%]">
        <img
          src="https://images.unsplash.com/photo-1617761141732-d481912af1a9?crop=entropy&cs=srgb&fm=jpg&q=85"
          alt=""
          className="h-full w-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0B132B]/70 via-[#0B132B]/55 to-[#0B132B]" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0B132B]/80 via-transparent to-[#0B132B]/40" />
      </motion.div>

      <motion.div
        style={{ opacity: fade }}
        className="relative mx-auto w-full max-w-6xl px-5 sm:px-8 pt-36 pb-12 sm:pb-16"
      >
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05, duration: 0.7, ease: EASE }}
          className="mb-5 text-[11px] sm:text-xs font-mono uppercase tracking-[0.3em] text-[#7CD4FF]"
        >
          PGDM 2026–28 · IMDR Pune · Corporate Finance
        </motion.p>

        <h1 className="font-serif font-bold tracking-tight leading-[0.98] text-[clamp(2.9rem,14vw,6.75rem)]">
          <RevealLine delay={0.15}>Atharva</RevealLine>
          <RevealLine delay={0.28}>
            <span className="italic text-accent">Godbole</span>
          </RevealLine>
        </h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.55, duration: 0.7, ease: EASE }}
          className="mt-6 max-w-xl text-base sm:text-lg text-slate-300 leading-relaxed"
        >
          Aspiring Corporate Finance professional — hands-on with ITR, TDS &
          GST, sharpening financial modelling and an AI-native workflow.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.7, ease: EASE }}
          className="mt-9 flex flex-wrap items-center gap-3.5"
        >
          <a
            data-testid="hero-download-cv-button"
            href={`${process.env.REACT_APP_BACKEND_URL || ""}/api/resume`}
            download
            className="group inline-flex items-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-semibold text-[#04121F] hover:scale-[1.03] active:scale-[0.98] transition-transform duration-200 shadow-[0_0_36px_rgba(0,163,255,0.35)]"
          >
            <Download className="h-4 w-4 transition-transform duration-200 group-hover:translate-y-0.5" />
            Download CV
          </a>
          <button
            data-testid="hero-contact-button"
            onClick={() => scrollToId("contact")}
            className="inline-flex items-center gap-2 rounded-full border border-white/25 px-6 py-3 text-sm font-semibold text-white hover:border-accent/70 hover:text-[#7CD4FF] hover:scale-[1.03] active:scale-[0.98] transition-all duration-200"
          >
            Contact me
            <ArrowDown className="h-4 w-4" />
          </button>
          <a
            data-testid="hero-linkedin-link"
            href={PROFILE.linkedin}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn profile"
            className="inline-flex items-center justify-center rounded-full border border-white/25 p-3 text-white hover:border-accent/70 hover:text-[#7CD4FF] hover:scale-[1.03] active:scale-[0.98] transition-all duration-200"
          >
            <Linkedin className="h-4 w-4" />
          </a>
        </motion.div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.95, duration: 0.8, ease: EASE }}
        className="relative border-t border-white/10 bg-[#0B132B]/60 backdrop-blur"
      >
        <div className="mx-auto max-w-6xl px-5 sm:px-8 grid grid-cols-3 divide-x divide-white/10">
          {HERO_STATS.map((s) => (
            <div key={s.label} className="py-5 sm:py-6 px-2 sm:px-6">
              <p className="font-mono text-lg sm:text-2xl font-semibold text-white">
                {s.value}
              </p>
              <p className="mt-1 text-[10px] sm:text-xs uppercase tracking-[0.18em] text-slate-400">
                {s.label}
              </p>
            </div>
          ))}
        </div>
      </motion.div>
    </section>
  );
}
