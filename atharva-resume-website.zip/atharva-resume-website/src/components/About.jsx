import { motion } from "framer-motion";
import { BarChart3, Sparkles, Theater } from "lucide-react";
import SectionHeading from "./SectionHeading";

const EASE = [0.16, 1, 0.3, 1];

const TRAITS = [
  {
    icon: BarChart3,
    title: "Detail-first",
    desc: "Taxation work rewards precision — every field, every deadline.",
  },
  {
    icon: Sparkles,
    title: "AI-native",
    desc: "Prompt engineering as a daily workflow, not a buzzword.",
  },
  {
    icon: Theater,
    title: "Stage-tested",
    desc: "3+ years of theatre: presence, timing, zero stage fright.",
  },
];

export default function About() {
  return (
    <section id="about" data-testid="about-section" className="py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading overline="About" title="Numbers first. Excuses never." />
        <div className="grid gap-10 lg:grid-cols-12 lg:gap-14">
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.7, ease: EASE }}
            className="lg:col-span-6"
          >
            <p className="text-lg sm:text-xl leading-relaxed text-slate-700 dark:text-slate-300">
              I'm Atharva Godbole — a PGDM (2026–28) student at IMDR, Pune, on
              the path into Corporate Finance.
            </p>
            <p className="mt-5 text-sm sm:text-base leading-relaxed text-slate-600 dark:text-slate-400">
              Three months at a CA office put me inside real ITR, TDS and GST
              work — deadlines, exactness, no shortcuts. I'm now building
              financial modelling depth, and I lean on AI daily to research,
              draft and analyse faster.
            </p>
            <p className="mt-5 text-sm sm:text-base leading-relaxed text-slate-600 dark:text-slate-400">
              Three years of theatre taught me what spreadsheets can't: how to
              hold a room.
            </p>
            <p className="mt-8 font-serif text-2xl italic text-slate-900 dark:text-white">
              — Atharva
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.7, delay: 0.12, ease: EASE }}
            className="lg:col-span-6 flex flex-col gap-6"
          >
            <div className="relative overflow-hidden rounded-2xl border border-slate-900/10 dark:border-white/10 max-h-[320px]">
              <img
                src="https://images.unsplash.com/photo-1501768909872-92489434169d?crop=entropy&cs=srgb&fm=jpg&q=85"
                alt="Abstract geometric sky pattern"
                className="h-56 sm:h-64 w-full object-cover saturate-[0.35] contrast-105"
              />
              <div className="absolute inset-0 bg-[#0B132B]/45 mix-blend-multiply" />
              <p className="absolute bottom-3 left-4 font-mono text-[10px] uppercase tracking-[0.25em] text-white/90">
                Pune · Maharashtra
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-3">
              {TRAITS.map((t) => (
                <div
                  key={t.title}
                  className="rounded-2xl border border-slate-900/10 dark:border-white/10 bg-white dark:bg-[#0F172A] p-5 transition-all duration-200 hover:border-accent/40 hover:shadow-[0_0_24px_rgba(0,163,255,0.12)]"
                >
                  <t.icon className="h-5 w-5 text-accent" />
                  <h3 className="mt-3 text-sm font-bold text-slate-900 dark:text-white">
                    {t.title}
                  </h3>
                  <p className="mt-1.5 text-xs leading-relaxed text-slate-600 dark:text-slate-400">
                    {t.desc}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
