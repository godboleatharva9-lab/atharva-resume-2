import { motion } from "framer-motion";

const SectionHeading = ({ overline, title }) => (
  <motion.div
    initial={{ opacity: 0, y: 24 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, amount: 0.15 }}
    transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
    className="mb-12 sm:mb-16"
  >
    <p className="mb-3 text-xs font-mono uppercase tracking-[0.25em] font-semibold text-accent">
      {overline}
    </p>
    <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-slate-900 dark:text-white">
      {title}
    </h2>
  </motion.div>
);

export default SectionHeading;
