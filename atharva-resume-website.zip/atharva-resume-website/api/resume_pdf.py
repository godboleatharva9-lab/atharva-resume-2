from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import simpleSplit
from reportlab.pdfgen import canvas

NAVY = HexColor("#0B132B")
SKY = HexColor("#00A3FF")
INK = HexColor("#0F172A")
SLATE = HexColor("#475569")
MUTED = HexColor("#94A3B8")
RULE = HexColor("#CBD5E1")


def build_resume_pdf(path):
    w, h = A4
    margin = 50
    c = canvas.Canvas(path, pagesize=A4)
    c.setTitle("Atharva Godbole - Resume")
    y = h - 58

    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 25)
    c.drawString(margin, y, "ATHARVA GODBOLE")
    y -= 21
    c.setFillColor(SKY)
    c.setFont("Helvetica", 11)
    c.drawString(margin, y, "Corporate Finance Aspirant  ·  PGDM (2026-28), IMDR Pune")
    y -= 17
    c.setFillColor(MUTED)
    c.setFont("Helvetica", 9)
    c.drawString(
        margin,
        y,
        "godboleatharva9@gmail.com   ·   linkedin.com/in/atharva-godbole-573024419   ·   Pune, India",
    )
    y -= 14
    c.setStrokeColor(SKY)
    c.setLineWidth(2)
    c.line(margin, y, w - margin, y)
    y -= 28

    def section(title):
        nonlocal y
        c.setFillColor(NAVY)
        c.setFont("Helvetica-Bold", 10.5)
        c.drawString(margin, y, title.upper())
        y -= 6
        c.setStrokeColor(RULE)
        c.setLineWidth(0.6)
        c.line(margin, y, w - margin, y)
        y -= 17

    def para(s, size=9.5, color=SLATE, leading=13):
        nonlocal y
        c.setFont("Helvetica", size)
        c.setFillColor(color)
        for line in simpleSplit(s, "Helvetica", size, w - 2 * margin):
            c.drawString(margin, y, line)
            y -= leading

    def entry(left, right=None):
        nonlocal y
        c.setFont("Helvetica-Bold", 10.5)
        c.setFillColor(INK)
        c.drawString(margin, y, left)
        if right:
            c.setFont("Helvetica", 9)
            c.setFillColor(MUTED)
            c.drawRightString(w - margin, y, right)
        y -= 14

    section("Profile")
    para(
        "PGDM student at IMDR, Pune, aspiring to a career in Corporate Finance. "
        "Hands-on taxation experience across ITR, TDS and GST, with a growing "
        "toolkit in financial modelling, MS Excel and AI-assisted analysis."
    )
    y -= 9

    section("Education")
    entry("PGDM — IMDR (DES Institute of Management Development and Research), Pune", "2026-28")
    y -= 9
    entry("Graduation — Indsearch Institute of Cost and Management", "2023-26")
    c.setFont("Helvetica", 9.5)
    c.setFillColor(SLATE)
    c.drawString(margin + 12, y, "CGPA 8.81 (A+)")
    y -= 15
    entry("HSC — MIT Junior College", "2023")
    y -= 9
    entry("SSC — Maharashtra Mandal English Medium School")
    y -= 15

    section("Experience")
    entry("Finance & Taxation Intern — CA Office", "3 months")
    for b in [
        "Prepared and filed Income Tax Returns (ITR) for individual clients.",
        "Handled TDS computation and filing.",
        "Assisted with GST filing and compliance work.",
    ]:
        c.setFillColor(SKY)
        c.setFont("Helvetica-Bold", 9.5)
        c.drawString(margin + 4, y, "•")
        c.setFont("Helvetica", 9.5)
        c.setFillColor(SLATE)
        c.drawString(margin + 15, y, b)
        y -= 13.5
    y -= 9

    section("Skills")
    para(
        "Taxation (ITR · TDS · GST)   ·   MS Excel   ·   Financial Modelling "
        "(currently learning)   ·   AI Tools & Prompt Engineering"
    )
    y -= 9

    section("Activities & Languages")
    para(
        "Theatre — 3+ years of stage experience: presence, timing and clear "
        "communication under pressure."
    )
    y -= 12
    para("Languages — English · Hindi · Marathi")
    y -= 14

    c.setStrokeColor(RULE)
    c.setLineWidth(0.6)
    c.line(margin, y, w - margin, y)
    c.setFont("Helvetica", 8)
    c.setFillColor(MUTED)
    c.drawString(margin, y - 14, "Atharva Godbole — Corporate Finance Aspirant")
    c.save()
    return path
