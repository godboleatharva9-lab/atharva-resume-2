import os
import re
import ipaddress
import logging
import httpx
from html import escape
from html.parser import HTMLParser
from urllib.parse import urlparse
from datetime import datetime, timezone
from pathlib import Path
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, EmailStr
from resume_pdf import build_resume_pdf

load_dotenv()

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Optional MongoDB (set MONGO_URL to a free MongoDB Atlas M0 cluster; the
# contact form still emails you without it).
mongo_client = None
if os.environ.get("MONGO_URL"):
    from motor.motor_asyncio import AsyncIOMotorClient
    mongo_client = AsyncIOMotorClient(os.environ["MONGO_URL"], serverSelectionTimeoutMS=5000)

OWNER_EMAIL = os.environ.get("OWNER_EMAIL", "")
RESEND_API_KEY = os.environ.get("RESEND_API_KEY", "")
EMAIL_FROM_NAME = os.environ.get("EMAIL_FROM_NAME", "Atharva Godbole")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- Email safety gate (defense in depth) ---
_SHORTENERS = ("bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "goo.gl", "rebrand.ly")
_CRED_ASK = ("reply with your password", "reply with the code", "send your password", "cvv",
             "send us your password", "enter your password below", "confirm your card number",
             "your full card number", "seed phrase", "recovery phrase", "verify your card",
             "social security number", "confirm your bank details")
_HOSTISH = re.compile(r"\b(?:https?://)?((?:[a-z0-9-]+\.)+[a-z]{2,})", re.I)


def _host_ok(host: str) -> bool:
    if not host or "xn--" in host:
        return False
    try:
        ipaddress.ip_address(host)
        return False
    except ValueError:
        pass
    return not any(host == s or host.endswith("." + s) for s in _SHORTENERS)


def _same_site(shown: str, real: str) -> bool:
    return shown == real or real.endswith("." + shown) or shown.endswith("." + real)


class _EmailScan(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags, self.urls, self.anchors = set(), [], []
        self._href, self._text = None, []

    def handle_starttag(self, tag, attrs):
        self.tags.add(tag.lower())
        self.urls += [v for k, v in attrs if k.lower() in ("href", "src") and v]
        if tag.lower() == "a":
            self._href = dict((k.lower(), v) for k, v in attrs).get("href")
            self._text = []

    def handle_data(self, data):
        if self._href is not None:
            self._text.append(data)

    def handle_endtag(self, tag):
        if tag.lower() == "a" and self._href is not None:
            self.anchors.append((self._href, "".join(self._text)))
            self._href, self._text = None, []


def _assert_safe_email(subject: str, html: str) -> None:
    scan = _EmailScan()
    scan.feed(html)
    if scan.tags & {"form", "input", "textarea", "select"}:
        raise ValueError("No forms or input fields in email (G2)")
    body = f"{subject}\n{html}".lower()
    for p in _CRED_ASK:
        if p in body:
            raise ValueError(f"Email asks the recipient for credentials: {p!r}")
    for url in scan.urls:
        low = url.strip().lower()
        if low.startswith(("mailto:", "tel:", "cid:", "#")):
            continue
        if not low.startswith("https://"):
            raise ValueError(f"Email links must be absolute https: {url!r}")
        host = urlparse(low).hostname or ""
        if not _host_ok(host) or urlparse(low).username is not None:
            raise ValueError(f"Unsafe URL in email: {url!r}")
    for href, text in scan.anchors:
        real = urlparse(href.strip().lower()).hostname or ""
        if not real:
            continue
        for m in _HOSTISH.finditer(text):
            if not _same_site(m.group(1).lower(), real):
                raise ValueError(f"Anchor text {m.group(1)!r} != link host {real!r}")


class ContactMessage(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    email: EmailStr
    message: str = Field(min_length=1, max_length=4000)


@app.get("/api/health")
async def health():
    return {"status": "ok"}


@app.post("/api/contact")
async def submit_contact(msg: ContactMessage):
    if mongo_client is not None:
        try:
            db = mongo_client[os.environ.get("DB_NAME", "portfolio")]
            await db.contact_messages.insert_one({
                "name": msg.name,
                "email": msg.email,
                "message": msg.message,
                "created_at": datetime.now(timezone.utc).isoformat(),
            })
        except Exception as e:
            logger.error(f"Mongo save skipped/failed: {e}")

    subject = f"New portfolio message from {msg.name}"
    html = (
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0">'
        '<tr><td style="padding:28px;font-family:Arial,Helvetica,sans-serif;background:#f6f8fb">'
        '<table role="presentation" width="100%" style="max-width:560px;background:#ffffff;'
        'border-radius:12px;border:1px solid #e2e8f0"><tr><td style="padding:28px">'
        '<p style="margin:0 0 6px;font-size:12px;letter-spacing:2px;color:#00A3FF;'
        'font-weight:700">PORTFOLIO CONTACT FORM</p>'
        f'<p style="margin:0 0 18px;font-size:20px;color:#0B132B">New message from {escape(msg.name)}</p>'
        f'<p style="margin:0 0 14px;font-size:14px;color:#475569"><strong>Reply to:</strong> {escape(msg.email)}</p>'
        '<p style="margin:0 0 8px;font-size:14px;color:#475569"><strong>Message:</strong></p>'
        '<p style="margin:0;font-size:14px;color:#0f172a;line-height:1.6">'
        f'{escape(msg.message).replace(chr(10), "<br>")}</p>'
        "</td></tr></table>"
        '<p style="margin:14px 0 0;font-size:11px;color:#94a3b8">Sent by '
        f"{escape(EMAIL_FROM_NAME)}'s portfolio website. This email never asks for "
        "passwords or card details.</p>"
        "</td></tr></table>"
    )

    _assert_safe_email(subject, html)

    if not (RESEND_API_KEY and OWNER_EMAIL):
        return {"status": "success", "emailed": False, "detail": "Email not configured"}

    try:
        async with httpx.AsyncClient(timeout=30) as http_client:
            resp = await http_client.post(
                "https://api.resend.com/emails",
                headers={"Authorization": f"Bearer {RESEND_API_KEY}"},
                json={
                    "from": f"{EMAIL_FROM_NAME} <onboarding@resend.dev>",
                    "to": [OWNER_EMAIL],
                    "reply_to": msg.email,
                    "subject": subject,
                    "html": html,
                },
            )
            resp.raise_for_status()
        return {"status": "success", "emailed": True}
    except httpx.HTTPStatusError as e:
        logger.error(f"Email send failed: {e.response.status_code} {e.response.text}")
        return {"status": "success", "emailed": False, "detail": "Message received, email failed"}
    except Exception as e:
        logger.error(f"Email send error: {e}")
        return {"status": "success", "emailed": False, "detail": "Message received, email failed"}


@app.get("/api/resume")
async def download_resume():
    path = build_resume_pdf("/tmp/Atharva_Godbole_Resume.pdf")
    return FileResponse(path, media_type="application/pdf", filename="Atharva_Godbole_Resume.pdf")
