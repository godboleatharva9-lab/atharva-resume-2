# Atharva Godbole — Resume Website

This project is a Create React App frontend with a FastAPI Python API for the contact form and downloadable PDF resume.

## Deploy on Vercel

1. Upload the full contents of this folder to a GitHub repository. Do not upload `node_modules`, `.env`, or real API keys.
2. In Vercel, create a new project and import the GitHub repository.
3. Keep the detected Create React App settings. Build command: `npm run build`; output directory: `build`.
4. Before deploying, add `OWNER_EMAIL` and `RESEND_API_KEY` under Project Settings → Environment Variables if you want the contact form to email you. `EMAIL_FROM_NAME` is optional. `MONGO_URL` is optional and only needed for message archiving.
5. Redeploy after adding environment variables.

## Local development

Install Node.js LTS, then run `npm install` and `npm start`. Frontend opens at http://localhost:3000.

To test the API locally, install Python 3.11+ and run `pip install -r api/requirements.txt`; then run the API from the `api` folder with `uvicorn index:app --port 8001`. In a root `.env.local`, set `REACT_APP_BACKEND_URL=http://localhost:8001` before starting React.

For Vercel local development, install the Vercel CLI and run `vercel dev` from the project root.

## Notes

- Do not commit real environment variables or secrets.
- The optional database is not required for contact email delivery.
- Confirm the contact form and PDF download after deployment.
